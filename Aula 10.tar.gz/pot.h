int potencia (int x,int y);
