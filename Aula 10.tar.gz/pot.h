int potencia (int x,int y);
int fatorado (int x,int y);
