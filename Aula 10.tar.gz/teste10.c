#include<stdio.h>
#include"pot.h"

int main(){
	//variaveis

int op,val1,val2;
	
	printf("Digite a Opção desejada: ");
	printf(" 1 para Fatorial ");
	printf(" 2 para Exponencial");
	scanf("%i",&op);

switch(op){

case 1:
	Break;
case 2:
	printf("Digite o primeiro valor:");
	scanf("%i",&val1);
	printf("Digite o segundo valor: ");
	scanf("%i",&val2);
	potencia(val1,val2);
	Break;

default:
	printf("Opção invalida");
	}
}
			
