#include<stdio.h>
#include"pot.h"

int main(){
	//variaveis

int op,val1,val2;
	//Tela
	printf("Digite a Opção desejada: ");
	printf("1 para Fatorial");
	printf("2 para Exponencial");
	scanf("%i",&op);

switch(op){

//Calculo de Fatorial
case 1:
	printf("Digite o valor para ser fatorado: ");
	scanf("%i",&val1);
	fatorado(val1);
	Break;
//Calculo de Exponencial
case 2:
	printf("Digite o primeiro valor:");
	scanf("%i",&val1);
	printf("Digite o segundo valor: ");
	scanf("%i",&val2);
	potencia(val1,val2);
	Break;

default:
	//Caso a Opção escolhida seja diferente de 1 ou 2
	printf("Opção invalida");
	}
}
			
